import './../style/Footer.css';
const Footer = () => {
    return (
        <div className="Footer wrapper">
                <p>&copy; Andre Luambua Mulaja</p>
        </div>
    );
}

export default Footer;