import "./../style/Ajoute.css";

const Ajoute = (props) =>{
    return (
        <div className="Ajoute">

        </div>
    );
}

export default Ajoute;