const products = [
    {
        id: 0,
        reference: 'lkos74se',
        libele: 'tasse',
        valeurEnStock: 45256,
        prixAchax: 4000,
        stock: 30
    },
    {
        id: 1,
        reference: 'lkos74se',
        libele: 'tasse',
        valeurEnStock: 45256,
        prixAchax: 4000,
        stock: 30
    },
    {
        id: 2,
        reference: 'lkos74se',
        libele: 'tasse',
        valeurEnStock: 45256,
        prixAchax: 4000,
        stock: 30
    },
    {
        id: 3,
        reference: 'lkos74se',
        libele: 'tasse',
        valeurEnStock: 45256,
        prixAchax: 4000,
        stock: 30
    },
    {
        id: 4,
        reference: 'lkos74se',
        libele: 'tasse',
        valeurEnStock: 45256,
        prixAchax: 4000,
        stock: 30
    },
    {
        id: 5,
        reference: 'lkos74se',
        libele: 'tasse',
        valeurEnStock: 45256,
        prixAchax: 4000,
        stock: 30
    }
];

export default products;