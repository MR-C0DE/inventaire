import './../style/Element.css';
import Navigation from "./Navigation";

const Element = () =>{
    return (
        <div className="Element wrapper">
            <Navigation/>
        </div>
    );
}

export default Element;